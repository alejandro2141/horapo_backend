--
-- PostgreSQL database dump
--

-- Dumped from database version 12.6 (Ubuntu 12.6-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.6 (Ubuntu 12.6-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agendas; Type: TABLE; Schema: public; Owner: conmeddb_user
--

CREATE TABLE public.agendas (
    id integer NOT NULL,
    professional_id bigint,
    center_id bigint,
    name text
);


ALTER TABLE public.agendas OWNER TO conmeddb_user;

--
-- Name: agendas_id_seq; Type: SEQUENCE; Schema: public; Owner: conmeddb_user
--

CREATE SEQUENCE public.agendas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agendas_id_seq OWNER TO conmeddb_user;

--
-- Name: agendas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: conmeddb_user
--

ALTER SEQUENCE public.agendas_id_seq OWNED BY public.agendas.id;


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: conmeddb_user
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    professional_id bigint,
    center text,
    professional_name text,
    date date,
    "time" time with time zone,
    address text,
    specialty text,
    is_public boolean DEFAULT true,
    center_id bigint,
    agenda_id bigint,
    reserve_patient_name text,
    reserve_patient_doc_id text,
    reserve_patient_age text,
    reserve_available boolean,
    reserve_patient_email text,
    reserve_patient_phone text,
    reserve_patient_insurance integer
);


ALTER TABLE public.appointments OWNER TO conmeddb_user;

--
-- Name: appointment2_id_seq; Type: SEQUENCE; Schema: public; Owner: conmeddb_user
--

CREATE SEQUENCE public.appointment2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appointment2_id_seq OWNER TO conmeddb_user;

--
-- Name: appointment2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: conmeddb_user
--

ALTER SEQUENCE public.appointment2_id_seq OWNED BY public.appointments.id;


--
-- Name: appointment2_reserve_patient_phone_seq; Type: SEQUENCE; Schema: public; Owner: conmeddb_user
--

CREATE SEQUENCE public.appointment2_reserve_patient_phone_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.appointment2_reserve_patient_phone_seq OWNER TO conmeddb_user;

--
-- Name: appointment2_reserve_patient_phone_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: conmeddb_user
--

ALTER SEQUENCE public.appointment2_reserve_patient_phone_seq OWNED BY public.appointments.reserve_patient_phone;


--
-- Name: assistant_professional; Type: TABLE; Schema: public; Owner: conmeddb_user
--

CREATE TABLE public.assistant_professional (
    id integer NOT NULL,
    assistant_id integer,
    professional_id integer
);


ALTER TABLE public.assistant_professional OWNER TO conmeddb_user;

--
-- Name: assistant_professional_id_seq; Type: SEQUENCE; Schema: public; Owner: conmeddb_user
--

CREATE SEQUENCE public.assistant_professional_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assistant_professional_id_seq OWNER TO conmeddb_user;

--
-- Name: assistant_professional_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: conmeddb_user
--

ALTER SEQUENCE public.assistant_professional_id_seq OWNED BY public.assistant_professional.id;


--
-- Name: assistants; Type: TABLE; Schema: public; Owner: conmeddb_user
--

CREATE TABLE public.assistants (
    id integer NOT NULL,
    name text,
    document_id text,
    phone1 text,
    phone2 text,
    address1 text,
    address2 text,
    email text,
    pass text,
    country text
);


ALTER TABLE public.assistants OWNER TO conmeddb_user;

--
-- Name: assistants_id_seq; Type: SEQUENCE; Schema: public; Owner: conmeddb_user
--

CREATE SEQUENCE public.assistants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assistants_id_seq OWNER TO conmeddb_user;

--
-- Name: assistants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: conmeddb_user
--

ALTER SEQUENCE public.assistants_id_seq OWNED BY public.assistants.id;


--
-- Name: center_professional; Type: TABLE; Schema: public; Owner: conmeddb_user
--

CREATE TABLE public.center_professional (
    id integer NOT NULL,
    center_id bigint,
    professional_id bigint
);


ALTER TABLE public.center_professional OWNER TO conmeddb_user;

--
-- Name: center_professional_id_seq; Type: SEQUENCE; Schema: public; Owner: conmeddb_user
--

CREATE SEQUENCE public.center_professional_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.center_professional_id_seq OWNER TO conmeddb_user;

--
-- Name: center_professional_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: conmeddb_user
--

ALTER SEQUENCE public.center_professional_id_seq OWNED BY public.center_professional.id;


--
-- Name: centers; Type: TABLE; Schema: public; Owner: conmeddb_user
--

CREATE TABLE public.centers (
    id integer NOT NULL,
    name text,
    address text,
    phone1 text,
    phone2 text,
    verified boolean,
    status integer
);


ALTER TABLE public.centers OWNER TO conmeddb_user;

--
-- Name: centers_id_seq; Type: SEQUENCE; Schema: public; Owner: conmeddb_user
--

CREATE SEQUENCE public.centers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.centers_id_seq OWNER TO conmeddb_user;

--
-- Name: centers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: conmeddb_user
--

ALTER SEQUENCE public.centers_id_seq OWNED BY public.centers.id;


--
-- Name: professionals; Type: TABLE; Schema: public; Owner: conmeddb_user
--

CREATE TABLE public.professionals (
    id integer NOT NULL,
    name text,
    document_id text,
    phone1 text,
    phone2 text,
    address1 text,
    address2 text,
    email text,
    pass text,
    country text
);


ALTER TABLE public.professionals OWNER TO conmeddb_user;

--
-- Name: professionals_id_seq; Type: SEQUENCE; Schema: public; Owner: conmeddb_user
--

CREATE SEQUENCE public.professionals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.professionals_id_seq OWNER TO conmeddb_user;

--
-- Name: professionals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: conmeddb_user
--

ALTER SEQUENCE public.professionals_id_seq OWNED BY public.professionals.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: conmeddb_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text,
    password text,
    email text,
    phone text,
    role_assistant boolean,
    user_id integer,
    user_type integer
);


ALTER TABLE public.users OWNER TO conmeddb_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: conmeddb_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO conmeddb_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: conmeddb_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: agendas id; Type: DEFAULT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.agendas ALTER COLUMN id SET DEFAULT nextval('public.agendas_id_seq'::regclass);


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointment2_id_seq'::regclass);


--
-- Name: assistant_professional id; Type: DEFAULT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.assistant_professional ALTER COLUMN id SET DEFAULT nextval('public.assistant_professional_id_seq'::regclass);


--
-- Name: assistants id; Type: DEFAULT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.assistants ALTER COLUMN id SET DEFAULT nextval('public.assistants_id_seq'::regclass);


--
-- Name: center_professional id; Type: DEFAULT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.center_professional ALTER COLUMN id SET DEFAULT nextval('public.center_professional_id_seq'::regclass);


--
-- Name: centers id; Type: DEFAULT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.centers ALTER COLUMN id SET DEFAULT nextval('public.centers_id_seq'::regclass);


--
-- Name: professionals id; Type: DEFAULT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.professionals ALTER COLUMN id SET DEFAULT nextval('public.professionals_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: agendas; Type: TABLE DATA; Schema: public; Owner: conmeddb_user
--

INSERT INTO public.agendas VALUES (1, 1, 1, 'agendaname_id1_prof1_center1');
INSERT INTO public.agendas VALUES (2, 2, 2, 'Agenda2_proff2_centro2');
INSERT INTO public.agendas VALUES (3, 1, 2, 'Agenda3_prof1_center2');


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: conmeddb_user
--

INSERT INTO public.appointments VALUES (2, 11, 'Centro Salud Las Lilas de las Flores', 'Dr@ Juan Gonzales Chaptin Sanito', '2021-12-05', '23:00:00-03', 'Avenida Independencia 1450, Oficina 1234, San Antonio, RM Chile', 'Cardiologia', true, 23, 1, 'Juan alejandro morales Miranda', '13909371-2', NULL, false, 'Alejandro2141@gmail.c9m', '75397200', 2);
INSERT INTO public.appointments VALUES (3, 11, 'Centro Privado las Carmelitas', 'Julio Curandero de la Selva', '2021-12-05', '02:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM.  ', 'Urologia', true, 12, 1, 'aaaaaaaaaaaaaa', 'xxxxxxxxxxx', '33', true, 'asdf@zzzzzzzzzzzzzz', '77777777777', 3);
INSERT INTO public.appointments VALUES (1, 12, 'Consulta Privada', 'Dr@ Rosita Sanita Cura Los Dolores', '2021-12-05', '02:00:00-03', 'Avenida Providencia 1353, Oficina 1450, Providencia, Santiago, RM Chile', 'Oftalmologia', true, 22, 1, 'juan alejandro morales miranda', '13909371-2', NULL, false, 'alejandro2141@gmail.com', '7774729', 3);
INSERT INTO public.appointments VALUES (24, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', NULL, true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (25, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', NULL, true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (26, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', NULL, true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (27, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', '00', true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (30, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (31, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', false, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (32, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (33, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (34, 33, 'Centro salud', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', false, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (35, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', true, 44, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (36, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', true, 44, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (37, 33, 'Los Coligues', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', true, 44, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (38, 33, 'Centro de saud las condes', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', true, 44, 1, NULL, NULL, NULL, true, NULL, NULL, NULL);
INSERT INTO public.appointments VALUES (39, 33, 'Centro de saud las condes', 'Juan Sanito Cura Dolores', '2021-12-06', '23:00:00-03', 'Avenida Independencia 1234, Oficina 123132, independencia RM. ', 'Urologia', true, 44, 1, NULL, NULL, NULL, true, NULL, NULL, NULL);


--
-- Data for Name: assistant_professional; Type: TABLE DATA; Schema: public; Owner: conmeddb_user
--

INSERT INTO public.assistant_professional VALUES (1, 1, 1);
INSERT INTO public.assistant_professional VALUES (2, 2, 2);


--
-- Data for Name: assistants; Type: TABLE DATA; Schema: public; Owner: conmeddb_user
--

INSERT INTO public.assistants VALUES (1, 'Rosita Asistente del Doc', '13909371-3', '7774729', '7354333', 'Pasaje3, la cisterna, Santiago RM Chile', '', 'rosita', 'rosita', 'cl');
INSERT INTO public.assistants VALUES (2, 'Julia Recepcionista del doc', '1399999-2', '54345345', '1123123', 'Los Manantiales 132, Renca, Santiago, RM, Chile ', '', 'julia', 'julia', 'cl');


--
-- Data for Name: center_professional; Type: TABLE DATA; Schema: public; Owner: conmeddb_user
--

INSERT INTO public.center_professional VALUES (1, 1, 1);
INSERT INTO public.center_professional VALUES (2, 2, 1);


--
-- Data for Name: centers; Type: TABLE DATA; Schema: public; Owner: conmeddb_user
--

INSERT INTO public.centers VALUES (1, 'Urologos Asociados', 'Avenida los Dominicos 1535, Oficina 1503, Providencia Santiago Chile. ', '7778787', '1231231233', NULL, NULL);
INSERT INTO public.centers VALUES (2, 'Centro de Salud Privado', 'Avenida Gran Avenida, 2361, Oficina 9123, San Miguel, RM Chile', '12121221', '232332323', NULL, NULL);


--
-- Data for Name: professionals; Type: TABLE DATA; Schema: public; Owner: conmeddb_user
--

INSERT INTO public.professionals VALUES (1, 'Dr Chapatin Gonalez Sanito SinDolor', '13909371-2', '7778987', '123123123', 'MancoCapac 1670 Independencia Santiago RM. ', '', 'bbb', 'bbb', '');
INSERT INTO public.professionals VALUES (2, 'Doggy House Medico', '11111-9', '345345345', '', 'Los Maitenes de Nebrasca 1212, Dpto 3030, RM Santiago Chile. ', '', 'aaa', 'aaa', '');


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: conmeddb_user
--

INSERT INTO public.users VALUES (1, 'Rosita de los Rosales Rosas Rojas', 'abc', 'rosita@nada.cl', '56 9 75397201', true, NULL, NULL);
INSERT INTO public.users VALUES (2, 'Pedro Asistente de Salud ', 'ppp', 'alejandro2141@gmail.com', '56 9 7354333', false, NULL, NULL);
INSERT INTO public.users VALUES (3, 'aaa', 'aaa', 'aaa', '777', NULL, 3, NULL);
INSERT INTO public.users VALUES (4, 'Queen la Mujer que Cura', 'bbb', 'bbb', '777888777', false, 4, 3);


--
-- Name: agendas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: conmeddb_user
--

SELECT pg_catalog.setval('public.agendas_id_seq', 3, true);


--
-- Name: appointment2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: conmeddb_user
--

SELECT pg_catalog.setval('public.appointment2_id_seq', 39, true);


--
-- Name: appointment2_reserve_patient_phone_seq; Type: SEQUENCE SET; Schema: public; Owner: conmeddb_user
--

SELECT pg_catalog.setval('public.appointment2_reserve_patient_phone_seq', 2, true);


--
-- Name: assistant_professional_id_seq; Type: SEQUENCE SET; Schema: public; Owner: conmeddb_user
--

SELECT pg_catalog.setval('public.assistant_professional_id_seq', 2, true);


--
-- Name: assistants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: conmeddb_user
--

SELECT pg_catalog.setval('public.assistants_id_seq', 2, true);


--
-- Name: center_professional_id_seq; Type: SEQUENCE SET; Schema: public; Owner: conmeddb_user
--

SELECT pg_catalog.setval('public.center_professional_id_seq', 2, true);


--
-- Name: centers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: conmeddb_user
--

SELECT pg_catalog.setval('public.centers_id_seq', 2, true);


--
-- Name: professionals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: conmeddb_user
--

SELECT pg_catalog.setval('public.professionals_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: conmeddb_user
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: agendas agendas_pkey; Type: CONSTRAINT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.agendas
    ADD CONSTRAINT agendas_pkey PRIMARY KEY (id);


--
-- Name: appointments appointment2_pkey; Type: CONSTRAINT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointment2_pkey PRIMARY KEY (id);


--
-- Name: assistant_professional assistant_professional_pkey; Type: CONSTRAINT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.assistant_professional
    ADD CONSTRAINT assistant_professional_pkey PRIMARY KEY (id);


--
-- Name: assistants assistants_pkey; Type: CONSTRAINT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.assistants
    ADD CONSTRAINT assistants_pkey PRIMARY KEY (id);


--
-- Name: centers centers_pkey; Type: CONSTRAINT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.centers
    ADD CONSTRAINT centers_pkey PRIMARY KEY (id);


--
-- Name: professionals professionals_pkey; Type: CONSTRAINT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.professionals
    ADD CONSTRAINT professionals_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: conmeddb_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

